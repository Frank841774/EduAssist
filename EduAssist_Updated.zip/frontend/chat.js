const socket = io('http://localhost:5000');
const room = "chatroom1";
const userId = Math.random().toString(36).substring(7);

socket.emit('join', { room, user_id: userId });

socket.on('message', data => {
    console.log("Message:", data.text);
});

function sendMessage() {
    const message = document.getElementById("messageInput").value;
    socket.emit('message', { room, user_id: userId, text: message });
}

let localStream;
let peerConnection;

const servers = {
    iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
};

async function startCall() {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    document.getElementById("localVideo").srcObject = localStream;

    peerConnection = new RTCPeerConnection(servers);
    localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));

    peerConnection.ontrack = event => {
        document.getElementById("remoteVideo").srcObject = event.streams[0];
    };

    peerConnection.onicecandidate = event => {
        if (event.candidate) {
            socket.emit("ice-candidate", { recipient: "other_user", candidate: event.candidate });
        }
    };

    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    socket.emit("video-offer", { recipient: "other_user", offer });
}

socket.on("video-offer", async data => {
    peerConnection = new RTCPeerConnection(servers);
    localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));

    peerConnection.ontrack = event => {
        document.getElementById("remoteVideo").srcObject = event.streams[0];
    };

    peerConnection.onicecandidate = event => {
        if (event.candidate) {
            socket.emit("ice-candidate", { recipient: data.sender, candidate: event.candidate });
        }
    };

    await peerConnection.setRemoteDescription(new RTCSessionDescription(data.offer));
    const answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    socket.emit("video-answer", { recipient: data.sender, answer });
});

socket.on("video-answer", async data => {
    await peerConnection.setRemoteDescription(new RTCSessionDescription(data.answer));
});

socket.on("ice-candidate", async data => {
    await peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
});
