CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(200),
    role VARCHAR(10) CHECK (role IN ('student', 'tutor'))
);

CREATE TABLE payments (
    id SERIAL PRIMARY KEY,
    student_id INT REFERENCES users(id),
    tutor_id INT REFERENCES users(id),
    total_amount DECIMAL(10,2),
    commission DECIMAL(10,2),
    tutor_earnings DECIMAL(10,2)
);
