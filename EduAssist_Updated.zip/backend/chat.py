from flask import Flask, request
from flask_socketio import SocketIO, emit, join_room, leave_room

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

users = {}

@socketio.on('join')
def handle_join(data):
    room = data['room']
    join_room(room)
    users[data['user_id']] = request.sid
    emit('user_joined', {'user_id': data['user_id']}, room=room)

@socketio.on('leave')
def handle_leave(data):
    room = data['room']
    leave_room(room)
    emit('user_left', {'user_id': data['user_id']}, room=room)

@socketio.on('message')
def handle_message(data):
    room = data['room']
    emit('message', data, room=room)

@socketio.on('video-offer')
def handle_video_offer(data):
    recipient_sid = users.get(data['recipient'])
    if recipient_sid:
        emit('video-offer', data, room=recipient_sid)

@socketio.on('video-answer')
def handle_video_answer(data):
    recipient_sid = users.get(data['recipient'])
    if recipient_sid:
        emit('video-answer', data, room=recipient_sid)

@socketio.on('ice-candidate')
def handle_ice_candidate(data):
    recipient_sid = users.get(data['recipient'])
    if recipient_sid:
        emit('ice-candidate', data, room=recipient_sid)

if __name__ == '__main__':
    socketio.run(app, debug=True)
