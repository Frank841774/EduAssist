from flask import Blueprint, request, jsonify
from models import db, User, Payment

api_blueprint = Blueprint('api', __name__)

@api_blueprint.route('/signup', methods=['POST'])
def signup():
    data = request.json
    new_user = User(name=data['name'], email=data['email'], password=data['password'], role=data['role'])
    db.session.add(new_user)
    db.session.commit()
    return jsonify({"message": "User registered successfully"}), 201
