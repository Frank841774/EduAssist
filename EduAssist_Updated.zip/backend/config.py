import os

DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://user:password@localhost/eduassist')
SECRET_KEY = os.getenv('SECRET_KEY', 'your_secret_key')
PAYPAL_CLIENT_ID = os.getenv('PAYPAL_CLIENT_ID', 'your_paypal_client_id')
PAYPAL_SECRET = os.getenv('PAYPAL_SECRET', 'your_paypal_secret')
