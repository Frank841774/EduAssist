def process_payment(amount, student_id, tutor_id):
    commission_rate = 0.05
    commission = amount * commission_rate
    tutor_earnings = amount - commission

    new_transaction = Payment(
        student_id=student_id,
        tutor_id=tutor_id,
        total_amount=amount,
        commission=commission,
        tutor_earnings=tutor_earnings
    )
    db.session.add(new_transaction)
    db.session.commit()

    return {"message": "Payment successful", "tutor_earnings": tutor_earnings}
