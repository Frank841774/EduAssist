from flask import Flask
from flask_cors import CORS
from database import db
from routes import api_blueprint
import config

app = Flask(__name__)
CORS(app)
app.config.from_object(config)
db.init_app(app)
app.register_blueprint(api_blueprint)

if __name__ == '__main__':
    app.run(debug=True)
